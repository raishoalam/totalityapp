// components/ProductCard.js
import './index.css'

import {IoBagRemoveOutline} from 'react-icons/io5'

import {Link} from 'react-router-dom'

const ProductCard = ({product}) => (
  <div className="product-container">
    <div className="product-card">
      <Link className="links" to={`/product/${product.id}`}>
        <div className="image-cont">
          <img
            src={product.images[0]}
            alt={product.title}
            className="product-img"
          />
        </div>
        {/* Assuming product.images is an array of image URLs */}
        <h3 className="card-heading">{product.title}</h3>
        <p className="card-price">${product.price}</p>
        <div className="btn-cont">
          <button className="card-btn" type="button">
            Book Now
          </button>
          <IoBagRemoveOutline className="card-icons" />
        </div>
      </Link>
    </div>
  </div>
)

export default ProductCard
