// components/Home.js
import './index.css'

import {useEffect, useState} from 'react'

import ProductCard from '../ProductCard'

import Footer from '../Footer'

const Home = () => {
  const [products, setProducts] = useState([])

  useEffect(() => {
    fetch('https://dummyjson.com/products')
      .then(response => response.json())
      .then(data => {
        if (data && data.products && Array.isArray(data.products)) {
          setProducts(data.products)
        } else {
          console.error('Products array not found in response:', data)
        }
      })
      .catch(error => {
        console.error('Error fetching products:', error)
      })
  }, [])

  return (
    <div className="home">
      <h1 className="home-heading">PRODUCT PAGE</h1>
      <div className="product-list">
        {products.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
      <Footer />
    </div>
  )
}

export default Home
