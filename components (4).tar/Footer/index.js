// components/Footer.js
import './index.css'
import {FaWhatsapp, FaTwitter, FaInstagram} from 'react-icons/fa'
import {FaXTwitter} from 'react-icons/fa6'

const Footer = () => (
  <footer className="footer">
    <div className="footer-cont">
      <div>
        <h1 className="Footer-heading">Company</h1>
        <p className="footer-intro">About Us</p>
        <p className="footer-intro">Our Service</p>
        <p className="footer-intro">Privacy Policy</p>
        <p className="footer-intro">Affiliate Program</p>
      </div>
      <div>
        <h1 className="Footer-heading">Get Help</h1>
        <p className="footer-intro">FAQ</p>
        <p className="footer-intro">Shipping</p>
        <p className="footer-intro">Returns</p>
        <p className="footer-intro">Order Status</p>
        <p className="footer-intro">Payment Options</p>
      </div>
      <div>
        <h1 className="Footer-heading">Online Shop</h1>
        <p className="footer-intro">Watch</p>
        <p className="footer-intro">Bag</p>
        <p className="footer-intro">Shoes</p>
        <p className="footer-intro">Dress</p>
      </div>
      <div>
        <h1 className="Footer-heading">Follow Us</h1>
        <div className="footer-icons">
          <span className="footer-icon1">
            <FaWhatsapp />
          </span>
          <span className="footer-icon">
            <FaTwitter />
          </span>
          <span className="footer-icon">
            <FaInstagram />
          </span>
          <span className="footer-icon">
            <FaXTwitter />
          </span>
        </div>
      </div>
    </div>
    <hr />
    <p className="footer-copy">
      &copy; 2024 Created by Coder Raish. All rights reserved.
    </p>
  </footer>
)

export default Footer
