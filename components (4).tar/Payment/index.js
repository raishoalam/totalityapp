// components/Checkout.js
import './index.css'

import {CardElement, useStripe, useElements} from '@stripe/react-stripe-js'

import Footer from '../Footer'

const Checkout = () => {
  const stripe = useStripe()
  const elements = useElements()

  const handleSubmit = async event => {
    event.preventDefault()

    if (!stripe || !elements) {
      return
    }

    const cardElement = elements.getElement(CardElement)

    const {error, paymentMethod} = await stripe.createPaymentMethod({
      type: 'card',
      card: cardElement,
    })

    if (error) {
      console.error(error)
    } else {
      console.log(paymentMethod)
      // Call your backend to process payment with paymentMethod.id
    }
  }

  return (
    <div>
      <div className="checkout">
        <h2 className="payment-heading">Checkout Page</h2>
        <form className="form-section" onSubmit={handleSubmit}>
          <CardElement className="form-section" />
          <div>
            <button className="payment-btn" type="submit" disabled={!stripe}>
              Pay Now
            </button>
          </div>
          <hr />
        </form>
      </div>
      <Footer />
    </div>
  )
}

export default Checkout
