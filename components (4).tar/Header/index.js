// components/Header.js
import './index.css'

import {Link} from 'react-router-dom'

const Header = () => (
  <header>
    <nav className="nav-section">
      <ul className="nav-container">
        <h1 className="nav-heading">TOTALITY CROP</h1>
        <li className="nav-item">
          <Link className="nav-items" to="/">
            Home
          </Link>
        </li>
        <li>
          <Link className="nav-items" to="/checkout">
            Checkout
          </Link>
        </li>
      </ul>
    </nav>
  </header>
)

export default Header
