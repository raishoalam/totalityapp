// components/ProductDetails.js
import './index.css'
import {useEffect, useState} from 'react'
import {useParams} from 'react-router-dom'
import Footer from '../Footer'

const ProductDetails = () => {
  const {id} = useParams()
  const [product, setProduct] = useState(null)

  useEffect(() => {
    fetch(`https://dummyjson.com/products/${id}`)
      .then(response => response.json())
      .then(data => setProduct(data))
  }, [id])

  const handleAddToCart = () => {
    // Add logic to add product to cart
    console.log(`Product ${product.name} added to cart`)
  }

  if (!product) return <div>Loading...</div>

  return (
    <div>
      <div className="product-details">
        <h2>{product.name}</h2>
        <div className="detail-con">
          {product.thumbnail && (
            <img
              className="product-images"
              src={product.thumbnail}
              alt={product.name}
            />
          )}
        </div>
        <div className="product-info">
          <p className="desc">{product.description}</p>
          <p className="product-price">
            Price: <span>${product.price}</span>
          </p>
          <p className="product-brand">Brand: {product.brand}</p>
          <p className="product-rating">Rating: {product.rating}</p>
          <p className="category">category:{product.category}</p>

          <div>
            <button className="add-btn" type="button" onClick={handleAddToCart}>
              Add to Cart
            </button>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}

export default ProductDetails
